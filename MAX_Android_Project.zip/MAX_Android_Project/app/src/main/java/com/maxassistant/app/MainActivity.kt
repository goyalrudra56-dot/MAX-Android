package com.maxassistant.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("max_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        greet()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFF101116.toInt())
        }
        val title = TextView(this).apply {
            text = "MAX"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(0xFFFF8767.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "आपकी personal voice assistant"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFCCCCD2.toInt())
        }
        transcript = TextView(this).apply {
            text = "नमस्ते! मैं MAX हूँ। नीचे लिखें या माइक दबाकर बोलें।"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 22, 16, 22)
            setBackgroundColor(0xFF202129.toInt())
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
        }
        val sendRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply {
            hint = "MAX से कुछ कहिए..."
            setHintTextColor(0xFF9999A2.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            setSingleLine(true)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF292A33.toInt())
        }
        val send = Button(this).apply {
            text = "भेजें"
            setOnClickListener {
                val msg = input.text.toString().trim()
                if (msg.isNotEmpty()) {
                    input.setText("")
                    handleCommand(msg)
                }
            }
        }
        sendRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        sendRow.addView(send)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val mic = Button(this).apply {
            text = "🎙 बोलें"
            setOnClickListener { startListening() }
        }
        val settings = Button(this).apply {
            text = "⚙ AI सेटिंग"
            setOnClickListener { showSettings() }
        }
        controls.addView(mic)
        controls.addView(settings)

        root.addView(title)
        root.addView(subtitle)
        root.addView(space(16))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(space(12))
        root.addView(sendRow)
        root.addView(controls)
        setContentView(root)
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            ttsReady = true
        }
    }

    private fun greet() = speak("जी, मैं MAX हूँ। बताइए, क्या करना है?")

    private fun speak(message: String) {
        runOnUiThread {
            transcript.text = "MAX: $message"
            if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "max_reply")
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फोन में speech recognition उपलब्ध नहीं है।")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { speak("जी, सुन रही हूँ।") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { speak("आवाज़ समझ नहीं आई। फिर से कोशिश कीजिए।") }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = words?.firstOrNull().orEmpty()
                if (command.isNotBlank()) handleCommand(command)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "MAX को command दें")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        transcript.text = "आप: $raw\n\nMAX: सोच रही हूँ..."
        val q = raw.lowercase(Locale.ROOT)

        when {
            q.contains("youtube") || q.contains("यूट्यूब") -> {
                val search = raw.replace(Regex("(?i)youtube|यूट्यूब|खोलो|खोल|चलाओ|पर"), "").trim()
                val uri = if (search.isBlank()) Uri.parse("https://www.youtube.com")
                          else Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(search))
                openWeb(uri, "YouTube खोल रही हूँ।")
            }
            q.contains("whatsapp") && (q.contains("chat") || q.contains("चैट")) -> {
                val number = q.replace(Regex("[^0-9+]"), "")
                if (number.length >= 10) {
                    val clean = number.trimStart('+')
                    openWeb(Uri.parse("https://wa.me/$clean"), "WhatsApp chat खोल रही हूँ।")
                } else {
                    speak("WhatsApp chat खोलने के लिए देश कोड सहित फोन नंबर लिखिए, जैसे 919876543210।")
                }
            }
            q.contains("whatsapp") || q.contains("व्हाट्सएप") -> openPackage("com.whatsapp", "WhatsApp खोल रही हूँ।")
            q.contains("call") || q.contains("कॉल") || q.contains("फोन लग") -> {
                val digits = raw.filter { it.isDigit() }
                if (digits.length >= 10) {
                    speak("कॉल करने से पहले डायलर में नंबर जाँच लीजिए।")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
                } else speak("कॉल के लिए नंबर बताइए। मैं डायलर खोल दूँगी।")
            }
            q.contains("instagram") -> openPackage("com.instagram.android", "Instagram खोल रही हूँ।")
            q.contains("facebook") -> openPackage("com.facebook.katana", "Facebook खोल रही हूँ।")
            q.contains("chrome") -> openPackage("com.android.chrome", "Chrome खोल रही हूँ।")
            q.contains("समय") || q.contains("time") -> speak("अभी समय है " + java.text.SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(java.util.Date()))
            q.contains("बैटरी") || q.contains("battery") -> {
                val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra("level", -1) ?: -1
                speak(if (level >= 0) "आपके फोन की बैटरी $level प्रतिशत है।" else "बैटरी जानकारी नहीं मिल पाई।")
            }
            else -> askAI(raw)
        }
    }

    private fun openPackage(packageName: String, message: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak(message)
            startActivity(launch)
        } else speak("यह ऐप आपके फोन में इंस्टॉल नहीं है।")
    }

    private fun openWeb(uri: Uri, message: String) {
        speak(message)
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun showSettings() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        fun field(hint: String, key: String, default: String = ""): EditText {
            return EditText(this).apply {
                this.hint = hint
                setText(prefs.getString(key, default))
                if (key == "api_key") inputType = 129
                layout.addView(this)
                tag = key
            }
        }
        val endpoint = field("API endpoint", "endpoint", "https://api.openai.com/v1/chat/completions")
        val model = field("Model name", "model", "gpt-4o-mini")
        val apiKey = field("API key (optional)", "api_key")
        AlertDialogBuilder(this).show(layout) {
            prefs.edit()
                .putString("endpoint", endpoint.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("api_key", apiKey.text.toString().trim())
                .apply()
            speak("AI सेटिंग सेव हो गई।")
        }
    }

    private fun askAI(message: String) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            speak("यह command मेरे local controls में नहीं है। AI बातचीत के लिए AI सेटिंग में अपनी API key डालें।")
            return
        }
        val endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions").orEmpty()
        val model = prefs.getString("model", "gpt-4o-mini").orEmpty()
        thread {
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject()
                    .put("model", model)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", "You are MAX, a friendly female Hindi voice assistant. Reply concisely in the user's language."))
                        .put(JSONObject().put("role", "user").put("content", message)))
                    .put("temperature", 0.7)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("API error ${conn.responseCode}")
                val answer = JSONObject(response).getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message").getString("content")
                speak(answer)
                conn.disconnect()
            } catch (e: Exception) {
                speak("AI से कनेक्शन नहीं हो पाया। API endpoint और key जाँचिए।")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 41) speak("माइक permission के बिना मैं सुन नहीं सकती।")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}

/** Small helper to keep the settings dialog code dependency-free. */
private class AlertDialogBuilder(private val activity: Activity) {
    fun show(view: View, onSave: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("MAX AI Settings")
            .setView(view)
            .setPositiveButton("Save") { _, _ -> onSave() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
