# MAX Android Assistant (Starter Project)

यह MAX का पहला starter build है: Hindi speech input, Android Text-to-Speech, YouTube search/open, WhatsApp open/chat link, phone dialer, battery/time commands और optional OpenAI-compatible chat API.

## जरूरी बातें
- यह अभी हमेशा background में सुनने वाला wake-word assistant नहीं है। ऐप खोलकर mic दबाना होगा।
- WhatsApp chat खोलने के लिए नंबर देश कोड सहित दें (उदाहरण: `919876543210`)। WhatsApp voice/video call सीधे automate नहीं होती; chat खुलने के बाद user खुद call button दबाए।
- Phone call के लिए ऐप केवल dialer खोलता है; user को नंबर देखकर Call दबाना होगा।
- AI chat के लिए Settings में compatible API endpoint, model और API key डालें। API key फोन के private app preferences में रखी जाती है, फिर भी इसे साझा न करें। API usage पर provider शुल्क लगा सकता है।
- Speech recognition Android के speech service पर निर्भर है; कुछ डिवाइसों पर इंटरनेट जरूरी हो सकता है।
- `QUERY_ALL_PACKAGES` package visibility के लिए इस्तेमाल हुआ है; Play Store पर publish करने से पहले इसकी policy जरूरत जाँचें।

## Android Studio build
1. ZIP extract करें।
2. Android Studio में `MAX_Android_Project` folder खोलें।
3. Android SDK Platform 35 और JDK 17 उपलब्ध रखें।
4. Gradle sync करें।
5. Build > Build APK(s).

## Termux build (advanced)
Android app build करने के लिए केवल Termux install होना काफी नहीं है। Android SDK, platform 35, build-tools और Gradle/AGP compatible Java 17 environment चाहिए। यह setup हर फोन पर straightforward नहीं होता।

पहले Java/Gradle जाँचें:
```bash
pkg update
pkg install openjdk-17 gradle unzip -y
java -version
gradle --version
```

फिर project folder में:
```bash
gradle assembleDebug
```

यदि Android SDK location या SDK packages missing की error आए, तो Termux में SDK setup करना पड़ेगा। सबसे आसान और भरोसेमंद विकल्प Android Studio वाले PC या cloud CI build का है। APK का expected output:
`app/build/outputs/apk/debug/app-debug.apk`

## Version 1 scope
यह source project शुरुआती version है, final production assistant नहीं। पहले build और basic commands test करें; उसके बाद contact-name lookup, confirmation flows, accessibility actions और foreground wake-word service अलग-अलग चरणों में जोड़ें।
